import { config } from "dotenv";
config();

import { MongoClient, ObjectId } from "mongodb";

const DB_URI = process.env.DB_URI;
const DB_NAME = process.env.DB_NAME;

let client;

async function connectDB() {
  if (!client) {
    client = new MongoClient(DB_URI);
    await client.connect();
  }

  return client.db(DB_NAME);
}

export const handler = async (event) => {
  const db = await connectDB();

  for (const record of event.Records) {
    try {
      const key = decodeURIComponent(
        record.s3.object.Key.replace(/\+/g, " ")
      );

      console.log("Key:", key);

      const parts = key.split("/");

      let collection;
      let filter;
      let updateField;

      /**
       * users/profileImage/{userId}/file
       */
      if (parts[0] === "users") {
        collection = "users";
        filter = {
          _id: new ObjectId(parts[2]),
        };
        updateField = "profileImage";
      }

      /**
       * brands/{brandId}/logo/file
       */
      else if (parts[0] === "brands") {
        collection = "brands";
        filter = {
          _id: new ObjectId(parts[1]),
        };
        updateField = "logo";
      }

      /**
       * categories/{categoryId}/image/file
       */
      else if (
        parts[0] === "categories" &&
        parts[2] === "image"
      ) {
        collection = "categories";
        filter = {
          _id: new ObjectId(parts[1]),
        };
        updateField = "image";
      }

      /**
       * categories/{categoryId}/subCategories/{subCategoryId}/image/file
       */
      else if (
        parts[0] === "categories" &&
        parts[2] === "subCategories"
      ) {
        collection = "categories";

        filter = {
          _id: new ObjectId(parts[1]),
          "subCategories._id": new ObjectId(parts[3]),
        };

        await db.collection(collection).updateOne(filter, {
          $set: {
            "subCategories.$.image": key,
            updatedAt: new Date(),
          },
        });

        continue;
      }

      /**
       * products/{productId}/image/file
       */
      else if (
        parts[0] === "products" &&
        parts[2] === "image"
      ) {
        collection = "products";
        filter = {
          _id: new ObjectId(parts[1]),
        };
        updateField = "image";
      }

      /**
       * products/{productId}/gallery/file
       */
      else if (
        parts[0] === "products" &&
        parts[2] === "gallery"
      ) {
        collection = "products";

        await db.collection(collection).updateOne(
          {
            _id: new ObjectId(parts[1]),
          },
          {
            $push: {
              gallery: key,
            },
            $set: {
              updatedAt: new Date(),
            },
          }
        );

        continue;
      }

      /**
       * product-variants/{variantId}/image/file
       */
      else if (parts[0] === "product-variants") {
        collection = "productvariants";

        filter = {
          _id: new ObjectId(parts[1]),
        };

        updateField = "image";
      }

      /**
       * coupons/{couponId}/image/file
       */
      else if (parts[0] === "coupons") {
        collection = "coupons";

        filter = {
          _id: new ObjectId(parts[1]),
        };

        updateField = "image";
      } else {
        console.log("Unknown path:", key);
        continue;
      }

      const result = await db.collection(collection).updateOne(filter, {
        $set: {
          [updateField]: key,
          updatedAt: new Date(),
        },
      });

      console.log({
        collection,
        matched: result.matchedCount,
        modified: result.modifiedCount,
      });
    } catch (err) {
      console.error(err);
    }
  }

  return {
    statusCode: 200,
  };
};